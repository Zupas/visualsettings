# VisualSettings
Custom FiveM visual settings that will brighten police light & reduce glare!
** How To Install **
1. Open Your FiveM Folder - (Right Click FiveM Application And Then Navigate To Open File Location)
2. Open FiveM Application Data
3. Find And Open The Citizen Folder
5. Navigate Into The Common Folder
6. Open The Data Folder
7. Drag And Drop The visualsettings.dat File Into This Location, Replace All Files Necessary
8. Enjoy The Better Visuals! 
